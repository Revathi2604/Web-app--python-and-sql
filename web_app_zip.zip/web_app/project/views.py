from django.shortcuts import render, redirect
import mysql.connector

connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="password"
    )
cursor = connection.cursor()
cursor.execute("CREATE DATABASE IF NOT EXISTS User_table;")
cursor.execute("USE User_table;")
cursor.execute("""
    CREATE TABLE IF NOT EXISTS register_user (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        phone_number VARCHAR(15) NOT NULL,
        email_id VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL
    );
""")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS client_table (
        id INT AUTO_INCREMENT PRIMARY KEY,
        c_name VARCHAR(255) NOT NULL,
        industry VARCHAR(255) NOT NULL,
        need VARCHAR(255) NOT NULL,
        looking_for VARCHAR(255) NOT NULL,
        when_our_service VARCHAR(255) NOT NULL
    )
""")
cursor.execute("""
    CREATE TABLE IF NOT EXISTS feed_table (
        id INT AUTO_INCREMENT PRIMARY KEY,
        feed TEXT NOT NULL
    )
""")

connection.commit()
# cursor.close()
# connection.close()


def home(request):
    return render(request, 'home.html')

def reg(request):
    if request.method=='POST':
        name = request.POST.get('username')
        ph = request.POST.get('ph')
        email = request.POST.get('email')
        password = request.POST.get('password')

        sql = "INSERT INTO register_user (name, phone_number, email_id, password) VALUES (%s, %s, %s, %s)"
        val = (name, ph, email, password)
        cursor.execute(sql, val)
        connection.commit()
        return render(request, 'home.html', {'msg': 'Accout Sign-up Successfull', 'msg_alert': 'Success', 'on': 'block'})
    return render(request, 'reg.html')

def log(request):
    if request.method=='POST':
        name = request.POST.get('username')
        password = request.POST.get('password')

        sql = "SELECT * FROM register_user WHERE name = %s AND password = %s"
        val = (name, password)
        cursor.execute(sql, val)
        user = cursor.fetchone()
        if user is not None:
            return render(request, 'client.html', {'msg': 'Accout Login Successfull', 'msg_alert': 'Success', 'on': 'block'})
        else:
            return render(request, 'home.html', {'msg': 'Name or password somthing wrog', 'msg_alert': 'Issue', 'on': 'block'})
    return render(request, 'log.html')

def client(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        ind = request.POST.get('ind')
        need = request.POST.get('need')
        looking = request.POST.get('look')
        when = request.POST.get('when')
        print(name, ind, need, looking, when)
        sql = "INSERT INTO client_table (c_name, industry, need, looking_for, when_our_service) VALUES (%s, %s, %s, %s, %s)"
        val = (name, ind, need, looking, when)
        cursor.execute(sql, val)
        connection.commit()
        return redirect('feed')
    return render(request, 'client.html')

def feed(request):
    if request.method == 'POST':
        feed_msg = request.POST.get('feed')
        sql = "INSERT INTO feed_table (feed) VALUES (%s)"
        val = (feed_msg,)
        cursor.execute(sql, val)
        connection.commit()
        return redirect('home')
    return render(request, 'feed.html')


