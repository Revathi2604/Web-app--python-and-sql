from django.urls import path
from .views import *

urlpatterns = [
    path('', home, name='home'),
    path('log', log, name='log'),
    path('reg', reg, name='reg'),
    path('client', client, name='client'),
    path('feed', feed, name='feed'),
]